# YouTube Channel Blocker

Load this folder in `chrome://extensions` if you want the unpacked extension.

## Quick install

1. Open `chrome://extensions`
2. Turn on **Developer mode**
3. Click **Load unpacked**
4. Select this folder:
   `/Users/victorhumenhuk/Documents/👨‍💻 Extensions/(Chrome) YT Channel Blocker`

## Notes

- The active extension files are also kept in `yt-channel-blocker-chrome-source`
- `yt-channel-blocker-chrome-packaged` contains the packaged distribution copy
