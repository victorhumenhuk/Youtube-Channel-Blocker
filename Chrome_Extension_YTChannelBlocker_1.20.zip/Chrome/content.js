const PAGE_BLOCK_ID = "yt-channel-blocked-overlay";
const HIDDEN_CARD_ATTR = "data-yt-channel-blocked";
const HIDDEN_SECTION_ATTR = "data-yt-channel-blocked-section";

const CARD_SELECTORS = [
  // Desktop (ytd-)
  "ytd-rich-item-renderer",
  "ytd-video-renderer",
  "ytd-grid-video-renderer",
  "ytd-compact-video-renderer",
  "ytd-playlist-renderer",
  "ytd-radio-renderer",
  "ytd-channel-renderer",
  "ytd-reel-item-renderer",
  "ytd-rich-grid-slim-media",
  // Mobile (ytm-)
  "ytm-rich-item-renderer",
  "ytm-video-with-context-renderer",
  "ytm-compact-video-renderer",
  "ytm-shorts-lockup-view-model",
  "ytm-media-item",
].join(", ");

const SECTION_SELECTORS = [
  // Desktop
  "ytd-rich-section-renderer",
  "ytd-shelf-renderer",
  "ytd-item-section-renderer",
  "ytd-reel-shelf-renderer",
  // Mobile
  "ytm-item-section-renderer",
  "ytm-reel-shelf-renderer",
].join(", ");

let blockedState = ChannelBlockerStore.createEmptyState();
let applyQueued = false;
let lastKnownUrl = location.href;
let lastApplyTime = 0;
const THROTTLE_MS = 200;

/* ---- DOM helpers ---- */

function pickFirstText(selectors, root = document) {
  for (const sel of selectors) {
    const text = root.querySelector(sel)?.textContent?.replace(/\s+/g, " ").trim();
    if (text) return text;
  }
  return null;
}

function collectAliasesFromLinks(root) {
  const links = root.querySelectorAll(
    "a[href*='/channel/'], a[href*='youtube.com/channel/'], " +
    "a[href^='/@'], a[href*='youtube.com/@'], " +
    "a[href*='/user/'], a[href*='youtube.com/user/'], " +
    "a[href*='/c/'], a[href*='youtube.com/c/']"
  );

  const aliases = [];
  for (const link of links) {
    const alias = ChannelBlockerStore.aliasFromHref(link.href || link.getAttribute("href"));
    if (alias) aliases.push(alias);
  }

  return ChannelBlockerStore.uniqueAliases(aliases);
}

/* ---- Channel detection ---- */

function getCurrentChannel() {
  const aliases = [];
  const labels = [];
  let url = null;

  // 1. Current page URL
  const pageAlias = ChannelBlockerStore.aliasFromHref(location.href);
  if (pageAlias) {
    aliases.push(pageAlias);
    url = location.href;
  }

  // 2. Canonical link
  const canonicalUrl = document.querySelector("link[rel='canonical']")?.href;
  const canonicalAlias = ChannelBlockerStore.aliasFromHref(canonicalUrl);
  if (canonicalAlias) {
    aliases.push(canonicalAlias);
    url ||= canonicalUrl;
  }

  // 3. Video owner renderer
  const ownerLink =
    document.querySelector("ytd-video-owner-renderer a[href]") ||
    document.querySelector("#owner a[href]") ||
    document.querySelector("ytm-slim-owner-renderer a[href]");

  const ownerAlias = ChannelBlockerStore.aliasFromHref(ownerLink?.href);
  if (ownerAlias) {
    aliases.push(ownerAlias);
    url ||= ownerLink.href;
  }

  // 4. ytInitialData metadata (available in MAIN world / Safari; undefined in Chrome isolated world)
  const metadata = (typeof ytInitialData !== "undefined" ? ytInitialData : undefined)?.metadata?.channelMetadataRenderer;
  if (metadata?.externalId) {
    aliases.push(`channel:${String(metadata.externalId).toLowerCase()}`);
  }
  const vanityAlias = ChannelBlockerStore.aliasFromHref(metadata?.vanityChannelUrl);
  if (vanityAlias) {
    aliases.push(vanityAlias);
    url ||= metadata.vanityChannelUrl;
  }
  if (metadata?.title) labels.push(metadata.title);

  // 5. ytInitialPlayerResponse video details (available in MAIN world / Safari; undefined in Chrome isolated world)
  const videoDetails = (typeof ytInitialPlayerResponse !== "undefined" ? ytInitialPlayerResponse : undefined)?.videoDetails;
  if (videoDetails?.channelId) {
    aliases.push(`channel:${String(videoDetails.channelId).toLowerCase()}`);
  }
  if (videoDetails?.author) labels.push(videoDetails.author);

  // 6. DOM labels
  if (ownerLink?.textContent) labels.push(ownerLink.textContent);

  const pageLabel = pickFirstText([
    "ytd-channel-name yt-formatted-string",
    "#channel-name yt-formatted-string",
    "yt-dynamic-text-view-model h1",
    "h1.ytd-watch-metadata",
    "h1",
  ]);
  if (pageLabel) labels.push(pageLabel);

  // Include name aliases so search results can match by display name
  const bestLabel = labels.find(Boolean) || null;
  if (bestLabel) aliases.push(...ChannelBlockerStore.aliasesFromDisplayName(bestLabel));

  return ChannelBlockerStore.toChannelRecord({
    aliases,
    label: bestLabel,
    url,
  });
}

function getCardChannelRecord(card) {
  const aliases = collectAliasesFromLinks(card);
  const label = pickFirstText(
    [
      "#channel-name a",
      "#channel-name yt-formatted-string",
      "ytd-channel-name a",
      "ytd-channel-name yt-formatted-string",
      "#byline a",
      "#byline-container a",
      "#text a",
      "#subtitle a",
      "#text-container yt-formatted-string",
      "yt-formatted-string.ytd-channel-name",
      // Mobile selectors
      ".channel-name a",
      ".ytm-channel-name",
      "[class*='channel-name'] a",
      ".media-item-byline a",
    ],
    card
  );
  const url = card.querySelector(
    "a[href*='/channel/'], a[href^='/@'], a[href*='/user/'], a[href*='/c/']"
  )?.href;

  // Add name alias as fallback so cards without channel links can still match
  if (label) aliases.push(...ChannelBlockerStore.aliasesFromDisplayName(label));

  if (!aliases.length) return null;

  return ChannelBlockerStore.toChannelRecord({ aliases, label, url });
}

/* ---- Show / hide elements ---- */

function hideElement(el, attr) {
  el.style.setProperty("display", "none", "important");
  el.setAttribute(attr, "true");
}

function showElement(el, attr) {
  if (!el.hasAttribute(attr)) return;
  el.style.removeProperty("display");
  el.removeAttribute(attr);
}

/* ---- Blocked-page overlay ---- */

function showBlockedPageOverlay(channel, blockedRecord) {
  let overlay = document.getElementById(PAGE_BLOCK_ID);

  if (!overlay) {
    overlay = document.createElement("div");
    overlay.id = PAGE_BLOCK_ID;
    Object.assign(overlay.style, {
      position: "fixed",
      inset: "0",
      zIndex: "999999",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "24px",
      background: "rgba(8, 8, 12, 0.97)",
      color: "#f1f5f9",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      textAlign: "center",
    });
    document.documentElement.appendChild(overlay);
  }

  overlay.textContent = "";

  const card = document.createElement("div");
  Object.assign(card.style, {
    maxWidth: "440px", padding: "36px",
    border: "1px solid rgba(255,255,255,0.08)", borderRadius: "24px",
    background: "rgba(17,17,24,0.95)", boxShadow: "0 32px 80px rgba(0,0,0,0.5)",
  });

  const iconWrap = document.createElement("div");
  Object.assign(iconWrap.style, {
    margin: "0 auto 16px", width: "48px", height: "48px", borderRadius: "50%",
    background: "rgba(239,68,68,0.12)", display: "flex",
    alignItems: "center", justifyContent: "center",
  });
  iconWrap.innerHTML = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>`;

  const heading = document.createElement("h2");
  Object.assign(heading.style, {
    margin: "0 0 8px", fontSize: "22px", fontWeight: "700",
    lineHeight: "1.2", letterSpacing: "-0.01em",
  });
  heading.textContent = channel?.label || blockedRecord?.label || "This channel";

  const subtitle = document.createElement("p");
  Object.assign(subtitle.style, { margin: "0 0 4px", fontSize: "14px", color: "#94a3b8", lineHeight: "1.5" });
  subtitle.textContent = "This channel is on your block list.";

  const detail = document.createElement("p");
  Object.assign(detail.style, { margin: "0", fontSize: "13px", color: "#64748b", lineHeight: "1.5" });
  detail.textContent = "Videos and recommendations from this creator are hidden while the block is active.";

  card.append(iconWrap, heading, subtitle, detail);
  overlay.appendChild(card);

  document.documentElement.style.overflow = "hidden";
}

function removeBlockedPageOverlay() {
  document.getElementById(PAGE_BLOCK_ID)?.remove();
  document.documentElement.style.overflow = "";
}

/* ---- Blocking logic ---- */

function applyCardBlocking() {
  for (const card of document.querySelectorAll(CARD_SELECTORS)) {
    const channel = getCardChannelRecord(card);
    const blocked = channel
      ? ChannelBlockerStore.matchBlockedChannel(channel.aliases, blockedState)
      : null;

    if (blocked) {
      hideElement(card, HIDDEN_CARD_ATTR);
    } else {
      showElement(card, HIDDEN_CARD_ATTR);
    }
  }

  for (const section of document.querySelectorAll(SECTION_SELECTORS)) {
    const children = [...section.querySelectorAll(CARD_SELECTORS)];

    if (!children.length) {
      showElement(section, HIDDEN_SECTION_ATTR);
      continue;
    }

    if (children.every((c) => c.hasAttribute(HIDDEN_CARD_ATTR))) {
      hideElement(section, HIDDEN_SECTION_ATTR);
    } else {
      showElement(section, HIDDEN_SECTION_ATTR);
    }
  }
}

function applyPageBlocking() {
  const channel = getCurrentChannel();
  const blocked = channel
    ? ChannelBlockerStore.matchBlockedChannel(channel.aliases, blockedState)
    : null;

  if (blocked) {
    showBlockedPageOverlay(channel, blocked);
  } else {
    removeBlockedPageOverlay();
  }
}

function applyBlocking() {
  applyCardBlocking();
  applyPageBlocking();
}

function scheduleApplyBlocking() {
  if (applyQueued) return;
  applyQueued = true;
  const elapsed = Date.now() - lastApplyTime;
  const delay = Math.max(0, THROTTLE_MS - elapsed);
  setTimeout(() => {
    requestAnimationFrame(() => {
      applyQueued = false;
      lastApplyTime = Date.now();
      applyBlocking();
    });
  }, delay);
}

/* ---- State management ---- */

async function refreshBlockedState() {
  blockedState = await ChannelBlockerStore.getState();
  scheduleApplyBlocking();
}

function handleUrlChange() {
  if (location.href === lastKnownUrl) return;
  lastKnownUrl = location.href;
  scheduleApplyBlocking();
}

/* ---- Message handler ---- */

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    const type = String(message?.type ?? "").toLowerCase();
    const channel = getCurrentChannel();
    const blocked = Boolean(
      channel && ChannelBlockerStore.matchBlockedChannel(channel.aliases, blockedState)
    );

    if (type === "getcurrentchannel") {
      sendResponse({ channel, isBlocked: blocked });
      return;
    }

    if (type === "blockchannel") {
      const result = await ChannelBlockerStore.blockChannel(message.channel ?? channel);
      blockedState = result.state;
      scheduleApplyBlocking();
      sendResponse({ ok: Boolean(result.record), isBlocked: Boolean(result.record), channel: result.record });
      return;
    }

    if (type === "unblockchannel") {
      const result = await ChannelBlockerStore.unblockChannel(message.channel ?? channel);
      blockedState = result.state;
      scheduleApplyBlocking();
      sendResponse({ ok: Boolean(result.record), isBlocked: false });
      return;
    }

    if (type === "applyblocks") {
      scheduleApplyBlocking();
      sendResponse({ ok: true });
      return;
    }

    sendResponse({ ok: false });
  })();

  return true;
});

/* ---- Listeners ---- */

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[ChannelBlockerStore.STORAGE_KEY] || changes[ChannelBlockerStore.LEGACY_STORAGE_KEY]) {
    refreshBlockedState();
  }
});

document.addEventListener("yt-navigate-finish", handleUrlChange, true);
window.addEventListener("popstate", handleUrlChange, true);

new MutationObserver(() => {
  handleUrlChange();
  scheduleApplyBlocking();
}).observe(document.documentElement, { childList: true, subtree: true });

refreshBlockedState();
