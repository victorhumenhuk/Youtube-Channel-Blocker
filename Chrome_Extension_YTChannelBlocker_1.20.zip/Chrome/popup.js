const $ = (id) => document.getElementById(id);

const channelEl = $("channel");
const toggleBtn = $("toggle");
const statusEl = $("status");
const countEl = $("count");
const blockedListEl = $("blocked-list");
const emptyEl = $("empty");
const btnTextEl = toggleBtn.querySelector(".btn-text");
const btnIconEl = toggleBtn.querySelector(".btn-icon");

const BLOCK_ICON = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>`;
const UNBLOCK_ICON = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;

let currentChannel = null;
let blockedChannels = [];
let isBlocked = false;

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab ?? null;
}

function setBusyState(busy) {
  toggleBtn.disabled = busy || !currentChannel;
}

function updateToggleButton() {
  if (!currentChannel) {
    toggleBtn.disabled = true;
    toggleBtn.classList.remove("is-unblock");
    btnTextEl.textContent = "No channel detected";
    btnIconEl.innerHTML = BLOCK_ICON;
    return;
  }

  toggleBtn.disabled = false;
  toggleBtn.classList.toggle("is-unblock", isBlocked);
  btnTextEl.textContent = isBlocked ? "Unblock channel" : "Block channel";
  btnIconEl.innerHTML = isBlocked ? UNBLOCK_ICON : BLOCK_ICON;
}

function renderBlockedList() {
  countEl.textContent = blockedChannels.length;
  blockedListEl.innerHTML = "";

  if (!blockedChannels.length) {
    emptyEl.hidden = false;
    return;
  }

  emptyEl.hidden = true;

  for (const channel of blockedChannels) {
    const li = document.createElement("li");
    li.className = "blocked-item";

    const info = document.createElement("div");
    info.className = "blocked-info";

    const name = document.createElement("p");
    name.className = "blocked-name";
    name.textContent = channel.label;

    const handle = document.createElement("p");
    handle.className = "blocked-handle";
    handle.textContent =
      channel.aliases?.find((a) => a.startsWith("handle:"))?.replace("handle:", "@") ||
      channel.id.replace(/^[^:]+:/, "");

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn btn-ghost";
    btn.dataset.channelId = channel.id;
    btn.textContent = "Unblock";

    info.append(name, handle);
    li.append(info, btn);
    blockedListEl.appendChild(li);
  }
}

async function refreshBlockedChannels() {
  blockedChannels = await ChannelBlockerStore.getBlockedChannels();
  renderBlockedList();
}

function updateUI(message) {
  if (!currentChannel) {
    channelEl.textContent = "No channel detected";
    statusEl.textContent = message || "Open a YouTube video or channel page to manage that creator.";
    updateToggleButton();
    return;
  }

  channelEl.textContent = currentChannel.label;
  statusEl.textContent =
    message ||
    (isBlocked ? "This creator is blocked and hidden." : "This creator is currently allowed.");
  updateToggleButton();
}

async function detectCurrentChannel() {
  try {
    const tab = await getActiveTab();

    if (!tab?.id || !tab.url?.includes("youtube.com")) {
      currentChannel = null;
      isBlocked = false;
      updateUI("Open YouTube in the active tab to get started.");
      return;
    }

    const response = await chrome.tabs.sendMessage(tab.id, { type: "getCurrentChannel" });

    currentChannel = response?.channel ?? null;
    isBlocked = Boolean(response?.isBlocked);

    if (!currentChannel) {
      updateUI("Navigate to a video or channel page to detect the creator.");
      return;
    }

    updateUI();
  } catch {
    currentChannel = null;
    isBlocked = false;
    updateUI("Refresh the YouTube tab, then reopen this popup.");
  }
}

toggleBtn.addEventListener("click", async () => {
  if (!currentChannel) return;

  setBusyState(true);
  statusEl.textContent = "Saving...";

  try {
    if (isBlocked) {
      await ChannelBlockerStore.unblockChannel(currentChannel);
      isBlocked = false;
    } else {
      await ChannelBlockerStore.blockChannel(currentChannel);
      isBlocked = true;
    }

    await refreshBlockedChannels();
    updateUI(isBlocked ? "Channel blocked." : "Channel unblocked.");
  } catch {
    updateUI("Something went wrong. Please try again.");
  } finally {
    setBusyState(false);
  }
});

blockedListEl.addEventListener("click", async (event) => {
  const btn = event.target.closest("button[data-channel-id]");
  if (!btn) return;

  btn.disabled = true;

  try {
    await ChannelBlockerStore.unblockChannel(btn.dataset.channelId);
    await refreshBlockedChannels();

    if (currentChannel) {
      isBlocked = blockedChannels.some((ch) => ch.id === currentChannel.id);
      updateUI();
    }
  } finally {
    btn.disabled = false;
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;

  if (changes[ChannelBlockerStore.STORAGE_KEY] || changes[ChannelBlockerStore.LEGACY_STORAGE_KEY]) {
    refreshBlockedChannels();
    detectCurrentChannel();
  }
});

refreshBlockedChannels();
detectCurrentChannel();
