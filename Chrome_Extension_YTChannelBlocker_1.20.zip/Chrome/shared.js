(() => {
  const STORAGE_KEY = "blockedChannelsState";
  const LEGACY_STORAGE_KEY = "blockedChannels";
  const STORAGE_VERSION = 2;

  /* ---- Normalization ---- */

  function normalizeText(value) {
    return String(value ?? "").replace(/\s+/g, " ").trim();
  }

  function normalizeAbsoluteUrl(value) {
    if (!value) return null;
    try {
      return new URL(value, "https://www.youtube.com").toString();
    } catch {
      return null;
    }
  }

  function normalizePath(pathname) {
    if (!pathname) return null;
    const path = String(pathname).split(/[?#]/, 1)[0].replace(/\/+$/, "").trim();
    return path || null;
  }

  function normalizeAliasValue(value) {
    const normalized = normalizeText(value).replace(/^\/+|\/+$/g, "").toLowerCase();
    return normalized || null;
  }

  /* ---- Alias resolution ---- */

  function aliasFromPath(pathname) {
    const path = normalizePath(pathname);
    if (!path) return null;

    if (/^\/@[^/]+$/i.test(path)) {
      return `handle:${normalizeAliasValue(path.slice(2))}`;
    }

    const match = path.match(/^\/(channel|user|c)\/([^/]+)$/i);
    if (!match) return null;

    const [, kind, rawValue] = match;
    const value = normalizeAliasValue(rawValue);
    if (!value) return null;

    const type = kind.toLowerCase();
    if (type === "channel") return `channel:${value}`;
    if (type === "user") return `user:${value}`;
    return `custom:${value}`;
  }

  function aliasFromHref(href) {
    if (!href) return null;
    try {
      return aliasFromPath(new URL(href, "https://www.youtube.com").pathname);
    } catch {
      return null;
    }
  }

  function aliasesFromDisplayName(name) {
    const normalized = normalizeText(name)
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s._-]+/gu, "")
      .trim();
    return normalized ? [`name:${normalized}`] : [];
  }

  function uniqueAliases(values) {
    return [...new Set(values.filter(Boolean))];
  }

  function choosePrimaryAlias(aliases) {
    const ordered = uniqueAliases(aliases);
    for (const prefix of ["channel:", "handle:", "user:", "custom:", "name:"]) {
      const found = ordered.find((v) => v.startsWith(prefix));
      if (found) return found;
    }
    return ordered[0] ?? null;
  }

  /* ---- State & records ---- */

  function createEmptyState() {
    return { version: STORAGE_VERSION, channels: {} };
  }

  function mergeRecords(existing, next) {
    if (!existing) return next;

    const aliases = uniqueAliases([...(existing.aliases ?? []), ...(next.aliases ?? [])]);
    const id = choosePrimaryAlias(aliases);

    return {
      id,
      aliases,
      label: next.label || existing.label || id,
      url: next.url || existing.url || null,
      blockedAt: existing.blockedAt || next.blockedAt || Date.now(),
      updatedAt: Date.now(),
    };
  }

  function toChannelRecord(input) {
    const aliases = uniqueAliases([
      input?.id,
      input?.key,
      ...(input?.aliases ?? []),
      aliasFromHref(input?.url),
      aliasFromPath(input?.path),
    ]);

    const id = choosePrimaryAlias(aliases);
    if (!id) return null;

    return {
      id,
      aliases,
      label: normalizeText(input?.label ?? input?.name ?? id) || id,
      url: normalizeAbsoluteUrl(input?.url),
      blockedAt: Number(input?.blockedAt) || Date.now(),
      updatedAt: Date.now(),
    };
  }

  function sanitizeState(raw) {
    const base = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : createEmptyState();
    const state = createEmptyState();
    const records = base.channels && typeof base.channels === "object" ? Object.values(base.channels) : [];

    for (const rawRecord of records) {
      const record = toChannelRecord(rawRecord);
      if (!record) continue;
      state.channels[record.id] = mergeRecords(state.channels[record.id], record);
    }

    return state;
  }

  /* ---- Storage operations ---- */

  async function migrateStateIfNeeded() {
    const stored = await chrome.storage.local.get([STORAGE_KEY, LEGACY_STORAGE_KEY]);

    if (stored[STORAGE_KEY]?.version === STORAGE_VERSION) {
      return sanitizeState(stored[STORAGE_KEY]);
    }

    const state = sanitizeState(stored[STORAGE_KEY]);
    const legacy = stored[LEGACY_STORAGE_KEY];

    if (legacy && typeof legacy === "object") {
      for (const [key, value] of Object.entries(legacy)) {
        const record = toChannelRecord({
          id: key,
          aliases: [key],
          label: value?.label ?? value?.name,
          url: value?.url,
          blockedAt: value?.at,
        });
        if (!record) continue;
        state.channels[record.id] = mergeRecords(state.channels[record.id], record);
      }
    }

    await chrome.storage.local.set({ [STORAGE_KEY]: state });
    if (legacy) await chrome.storage.local.remove(LEGACY_STORAGE_KEY);

    return state;
  }

  async function getState() {
    return migrateStateIfNeeded();
  }

  async function setState(state) {
    const sanitized = sanitizeState(state);
    await chrome.storage.local.set({ [STORAGE_KEY]: sanitized });
    return sanitized;
  }

  function getBlockedChannelsFromState(state) {
    return Object.values(state?.channels ?? {}).sort((a, b) =>
      a.label.localeCompare(b.label, undefined, { sensitivity: "base" })
    );
  }

  async function getBlockedChannels() {
    return getBlockedChannelsFromState(await getState());
  }

  function matchBlockedChannel(candidateAliases, state) {
    const aliases = uniqueAliases(candidateAliases);

    for (const record of Object.values(state?.channels ?? {})) {
      if (record.id && aliases.includes(record.id)) return record;
      if ((record.aliases ?? []).some((a) => aliases.includes(a))) return record;
    }

    return null;
  }

  async function blockChannel(channel) {
    const record = toChannelRecord(channel);
    const state = await getState();

    if (!record) return { state, record: null };

    const existing = matchBlockedChannel(record.aliases, state);
    const merged = mergeRecords(existing, record);

    if (existing?.id && existing.id !== merged.id) {
      delete state.channels[existing.id];
    }

    state.channels[merged.id] = merged;
    const nextState = await setState(state);

    return { state: nextState, record: nextState.channels[merged.id] };
  }

  async function unblockChannel(channelOrId) {
    const state = await getState();
    const aliases =
      typeof channelOrId === "string"
        ? [channelOrId]
        : uniqueAliases([
            channelOrId?.id,
            channelOrId?.key,
            ...(channelOrId?.aliases ?? []),
            aliasFromHref(channelOrId?.url),
            aliasFromPath(channelOrId?.path),
          ]);

    const record = matchBlockedChannel(aliases, state);
    if (record?.id) delete state.channels[record.id];

    const nextState = await setState(state);
    return { state: nextState, record };
  }

  /* ---- Public API ---- */

  globalThis.ChannelBlockerStore = {
    STORAGE_KEY,
    LEGACY_STORAGE_KEY,
    STORAGE_VERSION,
    aliasFromHref,
    aliasFromPath,
    aliasesFromDisplayName,
    choosePrimaryAlias,
    createEmptyState,
    getBlockedChannels,
    getBlockedChannelsFromState,
    getState,
    matchBlockedChannel,
    setState,
    toChannelRecord,
    uniqueAliases,
    blockChannel,
    unblockChannel,
  };
})();
