const STORAGE_KEY="blockedChannels";

function normalizeChannelPath(path){
  if(!path) return null;
  const p=path.toLowerCase();
  if(p.startsWith("/channel/")) return `c:${p.split("/")[2]||""}`;
  if(p.startsWith("/@")) return `h:${p.split("/")[1]||""}`;
  if(p.startsWith("/user/")) return `u:${p.split("/")[2]||""}`;
  if(p.startsWith("/c/")) return `n:${p.split("/")[2]||""}`;
  return null;
}

function channelFromUrl(url){
  try{
    const u=new URL(url,location.origin);
    const key=normalizeChannelPath(u.pathname);
    if(!key) return null;
    return {key,label:u.pathname,url:u.href};
  }catch{return null;}
}

function getCurrentChannel(){
  const fromPath=channelFromUrl(location.href);
  if(fromPath) return fromPath;

  const ownerLink=
    document.querySelector("ytd-video-owner-renderer a[href*='/channel/']") ||
    document.querySelector("ytd-video-owner-renderer a[href^='/@']") ||
    document.querySelector("#owner a[href*='/channel/']") ||
    document.querySelector("#owner a[href^='/@']");

  if(ownerLink){
    const c=channelFromUrl(ownerLink.href);
    if(c){ c.label=ownerLink.textContent?.trim()||c.label; return c; }
  }
  return null;
}

async function getBlocked(){ const data=await chrome.storage.local.get(STORAGE_KEY); return data[STORAGE_KEY]||{}; }
async function setBlocked(map){ await chrome.storage.local.set({[STORAGE_KEY]:map}); }

function hideElement(el){ el.style.setProperty("display","none","important"); }

function showBlockedPageOverlay(channel){
  const id="yt-channel-blocked-overlay";
  if(document.getElementById(id)) return;
  const wrap=document.createElement("div");
  wrap.id=id;
  wrap.style.cssText="position:fixed;inset:0;z-index:999999;background:#0f0f0f;color:#fff;display:flex;align-items:center;justify-content:center;font-family:Arial,sans-serif;text-align:center;padding:24px;";
  wrap.innerHTML=`<div><h2 style="margin:0 0 8px;">Channel Blocked</h2><p style="margin:0;">${(channel?.label||channel?.key||"This channel")} is blocked.</p></div>`;
  document.documentElement.appendChild(wrap);
}

async function applyBlocking(){
  const blocked=await getBlocked();
  const current=getCurrentChannel();
  if(current&&blocked[current.key]) showBlockedPageOverlay(current);

  const cards=document.querySelectorAll("ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer, ytd-playlist-renderer, ytd-channel-renderer, ytd-reel-item-renderer");
  cards.forEach((card)=>{
    const links=card.querySelectorAll("a[href*='/channel/'], a[href^='/@'], a[href*='/user/'], a[href*='/c/']");
    for(const a of links){
      const c=channelFromUrl(a.href);
      if(c&&blocked[c.key]){ hideElement(card); break; }
    }
  });
}

chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  (async()=>{
    const blocked=await getBlocked();
    const channel=getCurrentChannel();

    if(msg.type==="getCurrentChannel"){ sendResponse({channel,isBlocked:!!(channel&&blocked[channel.key])}); return; }
    if(msg.type==="blockChannel"&&msg.channel?.key){ blocked[msg.channel.key]={label:msg.channel.label,at:Date.now()}; await setBlocked(blocked); await applyBlocking(); sendResponse({ok:true,isBlocked:true}); return; }
    if(msg.type==="unblockChannel"&&msg.channel?.key){ delete blocked[msg.channel.key]; await setBlocked(blocked); await applyBlocking(); sendResponse({ok:true,isBlocked:false}); return; }

    sendResponse({ok:false});
  })();
  return true;
});

new MutationObserver(()=>applyBlocking()).observe(document.documentElement,{childList:true,subtree:true});
applyBlocking();
