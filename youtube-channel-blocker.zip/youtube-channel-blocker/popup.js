const channelEl = document.getElementById("channel");
const toggleBtn = document.getElementById("toggle");
const statusEl = document.getElementById("status");
let currentTabId = null, currentChannel = null, isBlocked = false;

async function getActiveTab(){ return (await chrome.tabs.query({active:true,currentWindow:true}))[0]; }
async function sendMessage(tabId,type,payload={}){ return chrome.tabs.sendMessage(tabId,{type,...payload}); }

function updateUI(){
  if(!currentChannel){ channelEl.textContent="No channel found on this page."; toggleBtn.textContent="Unavailable"; toggleBtn.disabled=true; return; }
  channelEl.textContent=currentChannel.label||currentChannel.key;
  toggleBtn.disabled=false;
  toggleBtn.classList.toggle("unblock",isBlocked);
  toggleBtn.textContent=isBlocked?"Unblock Channel":"Block Channel";
}

async function init(){
  try{
    const tab=await getActiveTab();
    if(!tab||!tab.id||!tab.url?.includes("youtube.com")){ channelEl.textContent="Open YouTube first."; toggleBtn.textContent="Unavailable"; return; }
    currentTabId=tab.id;
    const res=await sendMessage(currentTabId,"getCurrentChannel");
    currentChannel=res?.channel||null; isBlocked=!!res?.isBlocked; updateUI();
  }catch{ channelEl.textContent="Refresh the YouTube tab and try again."; toggleBtn.textContent="Unavailable"; toggleBtn.disabled=true; }
}

toggleBtn.addEventListener("click",async()=>{
  if(!currentChannel||currentTabId==null) return;
  toggleBtn.disabled=true; statusEl.textContent="Saving...";
  try{
    const type=isBlocked?"unblockChannel":"blockChannel";
    const res=await sendMessage(currentTabId,type,{channel:currentChannel});
    isBlocked=!!res?.isBlocked; statusEl.textContent=isBlocked?"Channel blocked.":"Channel unblocked."; updateUI();
  }catch{ statusEl.textContent="Could not update. Reload page and try again."; }
  finally{ toggleBtn.disabled=false; }
});

init();
